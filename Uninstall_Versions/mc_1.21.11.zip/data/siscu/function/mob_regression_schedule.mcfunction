
execute as @e[type=#siscu:phage_zombifiable_special,tag=siscu.mob_regression,limit=1,sort=random] at @s if function siscu:mob_regression run schedule function siscu:kill_schedule 10t
