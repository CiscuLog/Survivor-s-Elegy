#delete scoreboards



scoreboard objectives remove siscu.bees
scoreboard objectives remove siscu.block_holding
scoreboard objectives remove siscu.broth_data
scoreboard objectives remove siscu.broth_temperature
scoreboard objectives remove siscu.day
scoreboard objectives remove siscu.death
scoreboard objectives remove siscu.dimension
scoreboard objectives remove siscu.elytra_durability
scoreboard objectives remove siscu.enchantment_reroll
scoreboard objectives remove siscu.entity_health
scoreboard objectives remove siscu.fire_spring
scoreboard objectives remove siscu.grass_stealth
scoreboard objectives remove siscu.integer
scoreboard objectives remove siscu.item_frame_inv
scoreboard objectives remove siscu.left_game
scoreboard objectives remove siscu.light_sensor_cooldown
scoreboard objectives remove siscu.llama_color
scoreboard objectives remove siscu.pig_count
scoreboard objectives remove siscu.rotting_mob
scoreboard objectives remove siscu.skeleton_class
scoreboard objectives remove siscu.sleep_time
scoreboard objectives remove siscu.stray_armor
scoreboard objectives remove siscu.tofu_boost
scoreboard objectives remove siscu.tofu_boost_1
scoreboard objectives remove siscu.tofu_boost_2
scoreboard objectives remove siscu.tofu_boost_3
scoreboard objectives remove siscu.tofu_boost_4
scoreboard objectives remove siscu.tofu_boost_5
scoreboard objectives remove siscu.trader_timer
scoreboard objectives remove siscu.update_item
scoreboard objectives remove siscu.use_carrot
scoreboard objectives remove siscu.use_fungus
scoreboard objectives remove siscu.use_goat_horn
scoreboard objectives remove siscu.volatile
scoreboard objectives remove siscu.warped_food
scoreboard objectives remove siscu.withering
scoreboard objectives remove siscu.x_pos
scoreboard objectives remove siscu.y_pos
scoreboard objectives remove siscu.y_rotation
scoreboard objectives remove siscu.y_rotation_decimal
scoreboard objectives remove siscu.y_rotation_int
scoreboard objectives remove siscu.z_pos
scoreboard objectives remove siscu.zombifying

tellraw @a [{"text":"   Survivor's Elegy\n","color":"gold","bold":true},{"text":"succesfully cleared all scoreboards","bold":false}]