
# Death of custom stuff
execute as @e[type=#siscu:glowing_invulnerable,tag=fire_spring] run tag @s add siscu.dead_entity
execute as @e[type=#siscu:glowing_invulnerable,tag=siscu.fire_spring] run tag @s add siscu.dead_entity
execute as @e[type=#siscu:glowing_invulnerable,tag=siscu.sculk_plantoid] run tag @s add siscu.dead_entity
execute as @e[type=marker,tag=breach] run tag @s add siscu.dead_entity
execute as @e[type=#siscu:glowing_invulnerable,tag=siscu.broth_cauldron] run tag @s add siscu.dead_entity
execute as @e[type=#siscu:glowing_invulnerable,tag=siscu.mirage] run tag @s add siscu.dead_entity

execute if entity @e[type=#siscu:glowing_invulnerable,tag=siscu.dead_entity] run function siscu:kill_schedule

# Wolf regression to base wolf
execute as @e[type=#siscu:phage_zombifiable_special] if predicate siscu:variant_undead run tag @s add siscu.mob_regression
execute if entity @e[tag=siscu.mob_regression] run function siscu:mob_regression_schedule

schedule function siscu:remove_stuff 120s
