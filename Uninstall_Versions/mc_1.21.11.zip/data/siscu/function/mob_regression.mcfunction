
tag @s remove siscu.mob_regression
particle poof ~ ~ ~ 0 0 0 0.03 5
playsound entity.zombie_villager.cure neutral @a

execute if entity @s[type=wolf] run return run data merge entity @s {variant:"minecraft:pale"}
execute if entity @s[type=cat] run return run data merge entity @s {variant:"british_shorthair"}
data merge entity @s {variant:"temperate"}
